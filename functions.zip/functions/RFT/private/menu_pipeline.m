function menu_pipeline(handle, eventdata, varargin)

% This is a call-back for MENU_FIELDTRIP

ft_analysispipeline([], varargin{1});
