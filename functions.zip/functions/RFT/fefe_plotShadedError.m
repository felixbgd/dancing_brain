function fefe_plotShadedError(xval, yval, stderr)

hold on;

curve1 = yval + stderr;
curve2 = yval - stderr;
x2 = [xval, fliplr(xval)];
inBetween = [curve1, fliplr(curve2)];
c = findobj('Type', 'line').Color;
errArea = fill(x2, inBetween, c,'EdgeColor',c,'FaceAlpha',0.2,'EdgeAlpha',0.3,'HandleVisibility','off');

end