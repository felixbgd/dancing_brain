function [ output_data ] = Giac_bandPass( data, HP, LP, fo, notch )
%%
% Function using FieldTrip for BP filter and/or notch filter around 50Hz
% data is data FieldTrip structure, HP (high pass) LP (low pass), fo
% (filter order), notch = 'yesNotch' adds a 47-53 notch filter. If no HP or
% LP is wished, use a non-numeric value such as 'no'
%% 

    cfg                      = [];        
    cfg.continuous           = 'no';
    cfg.channel              = 'all';  
        
if isnumeric(LP) == 1    
    cfg.lpfilter             = 'yes';
    cfg.lpfreq               = LP;
    cfg.lpfilttype           = 'but';
    cfg.lpfiltdir            = 'twopass'; 
    cfg.lpfiltord            = fo;   
end

if isnumeric(HP) == 1
    cfg.hpfilter             = 'yes';
    cfg.hpfreq               = HP; 
    cfg.hpfilttype           = 'but';
    cfg.hpfiltdir            = 'twopass'; 
    cfg.hpfiltord            = fo;
end
      
if strcmp(notch,'yesNotch') == 1
    cfg.bsfilter             = 'yes';              % working as a NOTCH filter around 50Hz
    cfg.bsfreq               = [47 53];            % or whatever you deem appropriate
end

output_data = ft_preprocessing(cfg,data);

end

